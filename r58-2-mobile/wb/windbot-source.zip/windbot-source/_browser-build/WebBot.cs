// r37 WindBot in the browser: the JavaScript-facing entry point and the desktop replacements (Claude as builder, 7 Nov 2026).
// WindBot's own GameBehavior (unchanged) receives each server packet exactly as it would from a TCP socket, and whatever it
// would have sent back is collected and returned to JavaScript. Nothing in WindBot's decision code is touched.
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Runtime.InteropServices.JavaScript;
using WindBot.Game;
using YGOSharp.Network.Enums;
using YGOSharp.Network.Utils;
using YGOSharp.OCGWrapper;

namespace WindBot
{
    public static class Program
    {
        public static string AssetPath = "/wb/";
        // WindBot's executors call Program.Rand for random choices. Desktop WindBot seeds it from the clock; here it is seeded
        // per duel (WebBot.Create) so a watched duel can be replayed exactly.
        public static Random Rand = new Random(1);
    }

    public static partial class WebBot
    {
        private static readonly Dictionary<int, GameClient> Bots = new Dictionary<int, GameClient>();
        private static int _next = 1;
        private static bool _cardsLoaded;

        // rows: one card per line, tab-separated: id ot alias setcode type level race attribute atk def name
        [JSExport]
        public static int LoadCards(string rows)
        {
            var table = new DataTable();
            foreach (var (n, t) in new (string, Type)[] { ("id", typeof(int)), ("ot", typeof(int)), ("alias", typeof(int)), ("setcode", typeof(long)), ("type", typeof(long)), ("level", typeof(long)), ("race", typeof(long)), ("attribute", typeof(long)), ("atk", typeof(int)), ("def", typeof(int)), ("name", typeof(string)), ("desc", typeof(string)) })
                table.Columns.Add(n, t);
            foreach (var line in rows.Split('\n'))
            {
                if (line.Length == 0) continue;
                var f = line.Split('\t');
                table.Rows.Add(int.Parse(f[0]), int.Parse(f[1]), int.Parse(f[2]), long.Parse(f[3]), long.Parse(f[4]), long.Parse(f[5]), long.Parse(f[6]), long.Parse(f[7]), int.Parse(f[8]), int.Parse(f[9]), f[10], "");
            }
            using (var reader = table.CreateDataReader())
                while (reader.Read()) { CardsManager.Add(reader); NamedCardsManager.Add(reader); }
            _cardsLoaded = true;
            return table.Rows.Count;
        }

        // Creates one bot. ydk = the deck file text; dialog = the Dialogs/default.json text. Returns the bot id.
        [JSExport]
        public static int Create(string executor, string deckName, string ydk, string dialog, int seed)
        {
            if (!_cardsLoaded) throw new Exception("LoadCards first");
            Directory.CreateDirectory(Program.AssetPath + "Decks");
            Directory.CreateDirectory(Program.AssetPath + "Dialogs");
            File.WriteAllText(Program.AssetPath + "Decks/" + deckName + ".ydk", ydk);
            File.WriteAllText(Program.AssetPath + "Dialogs/default.json", dialog);
            Program.Rand = new Random(seed);
            DecksManager.Init();
            var client = new GameClient(executor, deckName);
            int id = _next++;
            Bots[id] = client;
            return id;
        }

        // One server packet in (STOC id byte + body, no length prefix); every packet the bot sends back, each with its u16 length.
        [JSExport]
        public static byte[] Packet(int id, byte[] packet)
        {
            var client = Bots[id];
            client.Connection.Out.Clear();
            using (var reader = new BinaryReader(new MemoryStream(packet)))
                client.Behavior.OnPacket(reader);
            var ms = new MemoryStream();
            foreach (var p in client.Connection.Out)
            {
                ms.WriteByte((byte)(p.Length & 0xff)); ms.WriteByte((byte)(p.Length >> 8)); ms.Write(p, 0, p.Length);
            }
            return ms.ToArray();
        }

        // What the bot sends when it connects (PLAYER_INFO + JOIN_GAME), framed like Packet's output.
        [JSExport]
        public static byte[] Hello(int id)
        {
            var client = Bots[id];
            client.Connection.Out.Clear();
            client.SendHello();
            var ms = new MemoryStream();
            foreach (var p in client.Connection.Out) { ms.WriteByte((byte)(p.Length & 0xff)); ms.WriteByte((byte)(p.Length >> 8)); ms.Write(p, 0, p.Length); }
            return ms.ToArray();
        }

        [JSExport]
        public static void Dispose(int id) { Bots.Remove(id); }

        public static void Main() { }
    }
}

namespace YGOSharp.Network
{
    // Replaces the TCP client: GameBehavior calls Send(...) exactly as before; the bytes are kept for JavaScript.
    public class YGOClient
    {
        public readonly List<byte[]> Out = new List<byte[]>();
        public bool Closed;
        public bool IsConnected => !Closed;
        public void Send(byte[] packet) { Out.Add(packet); }
        public void Send(BinaryWriter writer) { Send(((MemoryStream)writer.BaseStream).ToArray()); }
        public void Send(CtosMessage message) { using (var w = new BinaryWriter(new MemoryStream())) { w.Write((byte)message); Send(w); } }
        public void Send(CtosMessage message, byte value) { using (var w = new BinaryWriter(new MemoryStream())) { w.Write((byte)message); w.Write(value); Send(w); } }
        public void Send(CtosMessage message, int value) { using (var w = new BinaryWriter(new MemoryStream())) { w.Write((byte)message); w.Write(value); Send(w); } }
        public void Send(CtosMessage message, long value) { using (var w = new BinaryWriter(new MemoryStream())) { w.Write((byte)message); w.Write(value); Send(w); } }
        public void Close(Exception error = null) { Closed = true; }
    }
}

namespace WindBot.Game
{
    // Replaces the desktop GameClient (sockets, DNS): the same members GameBehavior uses.
    public class GameClient
    {
        public YGOSharp.Network.YGOClient Connection { get; private set; }
        public GameBehavior Behavior { get; private set; }
        public string Username = "WindBot";
        public string Deck, DeckFile, Dialog = "default";
        public int Hand = 0;
        public bool Debug = false, _chat = false;
        public GameClient(string executor, string deckFile)
        {
            Deck = executor; DeckFile = deckFile;
            Connection = new YGOSharp.Network.YGOClient();
            Behavior = new GameBehavior(this);
        }
        public void SendHello()
        {
            var packet = GamePacketFactory.Create(CtosMessage.PlayerInfo);
            packet.WriteUnicode(Username, 20);
            Connection.Send(packet);
            packet = GamePacketFactory.Create(CtosMessage.JoinGame);
            packet.Write((short)0); packet.Write(new byte[] { 0xAA, 0xBB }); packet.Write(0); packet.WriteUnicode("", 20); packet.Write(0);
            Connection.Send(packet);
        }
        public void Chat(string message, bool forced) { }
        public void Surrender() { Connection.Send(CtosMessage.Surrender); }
        public void Log(string message, int type) { if (type == 0 || Debug) Logger.WriteLine(message); }
    }
}

namespace YGOSharp.OCGWrapper
{
    // Replaces the SQLite readers: the rows come from the site's card data (WebBot.LoadCards), same column order as the cdb query.
    internal static class CardsManager
    {
        private static readonly Dictionary<int, Card> _cards = new Dictionary<int, Card>();
        internal static void Init(string unused) { }
        internal static void Add(IDataRecord r) { var c = new Card(r); _cards[c.Id] = c; }
        internal static Card GetCard(int id) { return _cards.TryGetValue(id, out var c) ? c : null; }
    }
    public static class NamedCardsManager
    {
        private static readonly Dictionary<long, NamedCard> _cards = new Dictionary<long, NamedCard>();
        public static void SetThreadSafe() { }
        public static void LoadDatabase(string unused) { }
        internal static void Add(IDataRecord r) { var c = new NamedCard(r); _cards[c.Id] = c; }
        internal static NamedCard GetCard(long id) { return _cards.TryGetValue(id, out var c) ? c : null; }
        public static IList<NamedCard> GetAllCards() { return new List<NamedCard>(_cards.Values); }
    }
}
