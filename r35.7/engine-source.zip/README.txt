ocgcore-wasm npm 0.1.2; wrapper 768af363e79bd5c646e9b59f4e74aaeac0625784
Core 8e5f4e4f0ab6b8ca750e8e1c91c1a58f407e3272
Lua 75ea9ccbea7c4886f30da147fb67b693b2624c26
The wrapper build scripts and engine sources are included. Place engine sources in wrapper/cpp/ygo and Lua sources in wrapper/cpp/lua, then follow wrapper/README.md and build.sh.
